<?php
session_start();
if (!isset($_SESSION['user'])) {
    echo '<script>alert("Vui long dang nhap")
            window.location.href = "login.php"</script>';
}
$username = $_SESSION['user'];
echo "<h1>Hello user <span style='color: red'>$username</span></h1>";
echo "<h3><a href='logout.php'>Click to Logout</a></h3>"
?>