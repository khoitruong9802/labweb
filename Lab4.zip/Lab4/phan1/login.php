<?php
session_start();
if (isset($_SESSION['user'])) {
    echo "<h1>Logout to change account</h1>";
    echo "<h3><a href='logout.php'>Click to Logout</a></h3>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row justify-content-around my-3">
            <div class="col-6 bg-light">
                <h1 class="fs-3 text-center">Log in</h1>
                <form action="" method="POST">
                    <div class="my-2">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" name="username">
                    </div>
                    <div class="my-2">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    <button class="btn btn-primary w-100 my-2" name="submit">Login</button>
                    <div>
                        Correct username password<br>
                        username = admin<br>
                        password = 123456
                    </div>
                </form>
                <?php
                    if (isset($_POST['submit'])) {
                        $username = $_POST['username'];
                        $password = $_POST['password'];
                        if ($username == 'admin' && $password == '123456') {
                            $_SESSION['user'] = $username;
                            echo '<script>alert("Dang nhap thanh cong")
                                    window.location.href = "info.php"</script>';
                        } else {
                            echo '<script>alert("Thong tin khong chinh xac")</script>';
                        }
                    }
                ?>
            </div>
        </div>
    </div>
</body>
</html>