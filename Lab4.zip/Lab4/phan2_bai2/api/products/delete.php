<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
require_once("db_connect.php");

$data = json_decode(file_get_contents("php://input"));

$id = $data->id;

$stmt = $db->prepare("DELETE FROM `products` WHERE `id` = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

// $massage = array(
//     'delete' => 'success';
// );
// echo json_encode($massage);

?>