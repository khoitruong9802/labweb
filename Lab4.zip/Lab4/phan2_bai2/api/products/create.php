<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
require_once("db_connect.php");

$data = json_decode(file_get_contents("php://input"));

$id = $data->id;
$name = $data->name;
$description = $data->description;
$price = $data->price;
$image = $data->image;

$massage = array(
    'id' => '',
    'name' => '',
    'description' => '',
    'image' => '',
    'create' => ''
);

$checkError = true;

$checkID = $db->query("SELECT * FROM `products` WHERE id=$id");
if ($checkID->num_rows > 0) {
    $checkError = false;
    $massage['id'] = 'Error: ID exists!';
}
if (strlen($name) < 5 || strlen($name) > 40) {
    $checkError = false;
    $massage['name'] = 'Error: Name invalid!';
}
if (strlen($description) > 5000) {
    $checkError = false;
    $massage['description'] = 'Error: Descriprion invalid!';
}
if (strlen($image) > 255) {
    $checkError = false;
    $massage['image'] = 'Error: Image invalid!';
}
if ($checkError == false) {
    $massage['create'] = 'failure';
    echo json_encode($massage);
    http_response_code(503);
    exit;
}

if ($checkError == true) {
    $stmt = $db->prepare("INSERT INTO `products` VALUES(?, ?, ?, ?, ?)");
    $stmt->bind_param("issds", $id, $name, $description, $price, $image);
    
    $stmt->execute();
    $massage['create'] = 'success';
    echo json_encode($massage);
    http_response_code(201);
}
?>