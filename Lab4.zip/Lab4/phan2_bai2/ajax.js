let web_start = (id) => {
    const ajax = new XMLHttpRequest();
    ajax.open('GET', 'b.html', true);
    ajax.send();
    ajax.onload = () => {
        document.getElementById('main-content').innerHTML = ajax.responseText;
    }
}
web_start();