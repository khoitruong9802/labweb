<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
  <?php
    $firstNameInvalid = '';
    $lastNameInvalid = '';
    $passwordInvalid = '';
    $emailInvalid = '';
    $aboutInvalid = '';
    $successMassage = '';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $checkError = true;

      $firstName = $_POST['firstName'];
      $lastName = $_POST['lastName'];
      $password = $_POST['password'];
      $email = $_POST['email'];
      $about = $_POST['about'];

      if (strlen($firstName) < 2 || strlen($firstName) > 30) {
        $checkError = false;
        $firstNameInvalid = 'Error: First name invalid!';
      }
      if (strlen($lastName) < 2 || strlen($lastName) > 30) {
        $checkError = false;
        $lastNameInvalid = 'Error: Last name invalid!';
      }
      if (strlen($password) < 2 || strlen($password) > 30) {
        $checkError = false;
        $passwordInvalid = 'Error: Password invalid!';
      }
      if (strlen($about) > 10000) {
        $checkError = false;
        $aboutInvalid = 'Error: About invalid!';
      }
      $emailLength = strlen($email);
      $indexOne = -1;
      $indexTwo = -1;
      for ($i = 0; $i < $emailLength; $i++) {
        if ($email[$i] == '@') {
          $indexOne = $i;
        }
        if ($email[$i] == '.') {
          $indexTwo = $i;
        }
      }
      if (!(0 < $indexOne && $indexOne < $indexTwo - 1 && $indexTwo < $emailLength - 1)) {
        $checkError = false;
        $emailInvalid = 'Error: Email invalid!';
      }
      if ($checkError == true) {
        $successMassage = "Complete!";
      }
    }
  ?>
  <div class="container">
    <div class="row justify-content-around">
      <div class="col-12 col-md-6 bg-light p-3 my-4">
        <form action="<?php echo $_SERVER["PHP_SELF"]?>" method="POST" id="my-form">
          <h1 class="h3 text-center">Đăng kí thành viên</h1>

          <label for="first-name">First Name</label>
          <div class="input-group">
            <input type="text" class="form-control" id="first-name" name="firstName" placeholder="First name">
          </div>
          <div class="text-danger"><?php echo $firstNameInvalid?></div>

          <label for="last-name">Last Name</label>
          <div class="input-group">
            <input type="text" class="form-control" id="last-name" name="lastName" placeholder="Last name">
          </div>
          <div class="text-danger"><?php echo $lastNameInvalid?></div>

          <label for="">Birthday (Day-Month-Year)</label>
          <div class="input-group w-50" id="birthday">
            <select name="day" id="day" class="form-select text-center"></select>
            <select name="month" id="month" class="form-select text-center"></select>
            <select name="year" id="year" class="form-select text-center"></select>
          </div>

          <label for="">Gender</label>
          <div class="input-group" id="gender-checkbox">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="gender" id="male" value="male" checked>
              <label class="form-check-label" for="male">
                Male
              </label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="gender" id="female" value="female">
              <label class="form-check-label" for="female">
                Female
              </label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="gender" id="other" value="other">
              <label class="form-check-label" for="female">
                Other
              </label>
            </div>
          </div>

          <label for="password">Password</label>
          <div class="input-group">
            <input type="password" class="form-control" id="password" name="password" placeholder="Password">
          </div>
          <div class="text-danger"><?php echo $passwordInvalid?></div>

          <label for="email">Email</label>
          <div class="input-group">
            <input type="text" class="form-control" id="email" name="email" placeholder="Email">
          </div>
          <div class="text-danger"><?php echo $emailInvalid?></div>

          <label for="country">Country</label>
          <div class="input-group">
            <select class="form-select" id="country" name="country">
              <option value="vietnam">Vietnam</option>
              <option value="australia">Australia</option>
              <option value="usa">United States</option>
              <option value="india">India</option>
              <option value="thailand">Thailand</option>
              <option value="laos">Laos</option>
              <option value="china">China</option>
              <option value="other" selected>Other</option>
            </select>
          </div>

          <label for="about">About</label>
          <div class="input-group">
            <textarea class="form-control" id="about" rows="3" name="about"></textarea>
          </div>
          <div class="text-danger"><?php echo $aboutInvalid?></div>
          <button type="submit" class="btn btn-primary me-3">Submit</button>
          <button type="button" class="btn btn-secondary" id="reset">Reset</button>

          <div class="text-success fs-4"><?php echo $successMassage?></div>
        </form>
        <script>
          //Birthday
          let select = "";
          let day = document.getElementById("day");
          for (let i = 1; i < 32; i++) {
            let newOption = document.createElement("option");
            newOption.innerHTML = i;
            newOption.value = i;
            day.appendChild(newOption);
          }
          let month = document.getElementById("month");
          for (let i = 1; i < 13; i++) {
            let newOption = document.createElement("option");
            newOption.innerHTML = i;
            newOption.value = i;
            month.appendChild(newOption);
          }
          let year = document.getElementById("year");
          for (let i = 1950; i < 2031; i++) {
            let newOption = document.createElement("option");
            newOption.innerHTML = i;
            newOption.value = i;
            year.appendChild(newOption);
          }
          //Form element
          let firstName = document.getElementById("first-name");
          let lastName = document.getElementById("last-name");
          let birthday = document.getElementById("birthday");
          let gender = document.getElementById("gender-checkbox");
          let password = document.getElementById("password");
          let email = document.getElementById("email");
          let country = document.getElementById("country");
          let about = document.getElementById("about");
          //Reset form
          function resetForm() {
            firstName.value = "";
            lastName.value = "";
            email.value = "";
            password.value = "";
            about.value = "";
            gender.children[0].children[0].checked = true;
            country[country.length - 1].selected = true;
            console.log(birthday[0]);
          }
          let reset = document.getElementById("reset");
          reset.addEventListener("click", resetForm);
        </script>
      </div>
    </div>
  </div>

</body>

</html>