<?php
    require 'db_connect.php';
    $product_id = $_GET['id'];

    $query = 'SELECT * FROM `products` WHERE `id` = '.$product_id;
    $result = $db->query($query);

    if (!$result->num_rows) {
        die("Cannot find this ID in database!");
    }
    

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Document</title>
    <style>
        .my-header {
            background-color: #78D5E3;
        }

        .my-header a {
            margin-right: 15px;
            color: blue;
        }

        /* .my-navbar {
            background-color: #B4FF9F;
        } */
        .my-navbar a {
            text-decoration: none;
            padding: 1% 10%;
        }

        .my-navbar-one a:hover {
            background-color: #d3f6d7;
        }

        .my-navbar h3 {
            background-color: #89E894;
        }

        /* .my-products {
            background-color: ghostwhite;
        } */

        .my-products img {
            max-width: 300px;
        }

        /* .my-footer {
            background-color: greenyellow;
        } */
    </style>
</head>

<body>
    <div class="container">
        <!-- Header -->
        <div class="my-header row align-items-center p-2 border border-1 border-dark">
            <div class="col-5 col-md-3 col-lg-2">
                <h1 class="fs-3">Site Tittle</h1>
            </div>
            <div class="col-7 col-md-5 col-lg-4">
                <a href="#">Categories</a>
                <a href="#">Contact us</a>
                <a href="#">Follow us</a>
            </div>
            <div class="col-12 col-md-4 col-lg-4 ms-auto">
                <form action="">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <!-- Navbar -->
            <div class="my-navbar my-navbar-one col-12 order-1 col-md-2 order-md-1 border border-1 border-dark p-0">
                <div class="d-flex flex-column">
                    <h3 class="fs-5 p-2 m-0 text-center">Category</h3>
                    <a href="#">Item 1...</a>
                    <a href="#">Item 2...</a>
                    <a href="#">Item 3...</a>
                    <a href="#">Item 4...</a>
                    <a href="#">Item 5...</a>
                </div>
                <div class="d-flex flex-column">
                    <h3 class="fs-5 p-2 m-0 text-center">Top products</h3>
                    <a href="#">Item 1...</a>
                    <a href="#">Item 2...</a>
                    <a href="#">Item 3...</a>
                    <a href="#">Item 4...</a>
                    <a href="#">Item 5...</a>
                </div>
            </div>
            <!-- Products -->
            <div class="my-products col-12 order-3 col-md-8 order-md-2 border border-1 border-dark">
                <h2 class="fs-5 my-3">
                    <a href="list.php">Home</a>
                    <span> > </span>
                    <a href="#">Main Category</a>
                </h2>
                <div class="row my-2">
                    <?php
                        $row = $result->fetch_assoc();
                        $image = $row['image'];
                        $name = $row['name'];
                        $description = $row['description'];
                        $price = $row['price'];
                        echo '
                            <div class="col-12 col-md-6 text-center">
                                <img src="'.$image.'" class="img-fluid w-100" alt="">
                            </div>
                            <div class="col-12 col-md-6">
                                <h2 class="fs-3">'.$name.'</h2>
                                <div class="fs-5 fw-bold">Description:</div>
                                <div>'.$description.'</div>
                                <div class="fw-bold mt-2">Price: '.$price.'Đ</div>
                                <a href="#">
                                    <button type="button" class="btn btn-primary my-2">BUY NOW</button>
                                </a>
                            </div>
                            ';
                    ?>
                </div>
                <!-- <div class="row">
                    <div class="fs-5 fw-bold">Description:</div>
                    <div>Lorem ipsum, dolor sit amet consectetur adipisicing elit. In repellendus accusamus dicta fugit
                        facere blanditiis temporibus a, quia, provident odio deleniti aspernatur vel voluptatum
                        mollitia. Corrupti praesentium quos eligendi vero doloremque ea ipsam? Voluptatem eaque hic
                        veniam quia. Ullam est officia consequatur qui, dicta magnam. Quibusdam sed provident quidem
                        molestiae.
                    </div>
                </div> -->
            </div>
            <!-- Navbar -->
            <div class="my-navbar my-navbar-two col-12 order-2 col-md-2 order-md-3 border border-1 border-dark text-center">
                <a href="../phan2_bai3/a.php" class="w-100">
                    <button class="btn btn-info my-3">EDIT PRODUCTS</button>
                </a>
            </div>
        </div>
        <!-- Footer -->
        <div class="my-footer row border border-1 border-dark">
            <div class="col-12 text-center">
                <div class="fw-bold">
                    Footer Information
                </div>
                <a href="#">Link 1</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
            </div>
        </div>
    </div>
</body>

</html>