<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "shop";

$db = new mysqli($servername, $username, $password, $database);
if ($db->connect_errno) {
    die("Could not connect: ".$db->connect_error);
}
$db->set_charset("utf8");
?>