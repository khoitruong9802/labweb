<?php
    require 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Document</title>
    <style>
        .my-header {
            background-color: #78D5E3;
        }
        .my-header a{
            margin-right: 15px;
            color: blue;
        }
        /* .my-navbar {
            background-color: #B4FF9F;
        } */
        .my-navbar a {
            text-decoration: none;
            padding: 1% 10%;
        }
        .my-navbar-one a:hover {
            background-color: #d3f6d7;
        }
        .my-navbar h3 {
            background-color: #89E894;
        }
        /* .my-products {
            background-color: ghostwhite;
        } */
        .my-products img {
            width: 190px;
            height: 190px;
        }
        /* .my-footer {
            background-color: greenyellow;
        } */
    </style>
</head>

<body>
    <div class="container">
        <!-- Header -->
        <div class="my-header row align-items-center p-2 border border-1 border-dark">
            <div class="col-5 col-md-3 col-lg-2">
                <h1 class="fs-3">Site Tittle</h1>
            </div>
            <div class="col-7 col-md-5 col-lg-4">
                <a href="#">Categories</a>
                <a href="#">Contact us</a>
                <a href="#">Follow us</a>
            </div>
            <div class="col-12 col-md-4 col-lg-4 ms-auto">
                <form action="">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <!-- Navbar -->
            <div class="my-navbar my-navbar-one col-12 order-1 col-md-2 order-md-1 border border-1 border-dark p-0">
                <div class="d-flex flex-column">
                    <h3 class="fs-5 p-2 m-0 text-center">Category</h3>
                    <a href="#">Item 1...</a>
                    <a href="#">Item 2...</a>
                    <a href="#">Item 3...</a>
                    <a href="#">Item 4...</a>
                    <a href="#">Item 5...</a>
                </div>
                <div class="d-flex flex-column">
                    <h3 class="fs-5 p-2 m-0 text-center">Top products</h3>
                    <a href="#">Item 1...</a>
                    <a href="#">Item 2...</a>
                    <a href="#">Item 3...</a>
                    <a href="#">Item 4...</a>
                    <a href="#">Item 5...</a>
                </div>
            </div>
            <!-- Products -->
            <div class="my-products col-12 order-3 col-md-8 order-md-2 border border-1 border-dark">
                <h2 class="fs-2 text-center my-3">Top products</h2>
                <div class="row">
                    <?php                    
                        $query = "SELECT * FROM products";
                        $result = $db->query($query);

                        while ($row = $result->fetch_assoc()) {
                            $product_id = $row['id'];
                            $image = $row['image'];
                            $name = $row['name'];
                            $price = $row['price'];

                            echo '<div class="col-12 col-md-6 col-lg-4 my-item">
                                <div class="container text-center border border-dark mb-4">
                                    <img src="'.$image.'" class="img-fluid" alt="">
                                    <div class="my-2">'.$name.'</div>
                                    <div class="my-2 fw-bold">Price: '.$price.'Đ</div>
                                    <a href="detail.php?id='.$product_id.'">
                                        <button class="btn btn-primary mb-1">BUY NOW</button>
                                    </a>
                                </div>
                            </div>';
                        }
                    ?>
                </div>
                <div class="row">
                    <nav aria-label="Page navigation">
                        <ul class="pagination">
                            <li class="page-item">
                            <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <!-- Navbar -->
            <div class="my-navbar my-navbar-two col-12 order-2 col-md-2 order-md-3 border border-1 border-dark text-center">
                <a href="../phan2_bai3/a.php" class="w-100">
                    <button class="btn btn-info my-3">EDIT PRODUCTS</button>
                </a>
            </div>
        </div>
        <!-- Footer -->
        <div class="my-footer row border border-1 border-dark">
            <div class="col-12 text-center">
                <div class="fw-bold">
                    Footer Information
                </div>
                <a href="#">Link 1</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
            </div>
        </div>
    </div>
</body>

</html>