<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-6 bg-light">
                <h1 class="text-center">Update Product</h1>
                <?php
                    require 'db_connect.php';

                    $init_id = $_GET['id'];
                    $query = "SELECT * FROM `products` WHERE id = ".$init_id;
                    $result = $db->query($query);

                    $row = $result->fetch_assoc();

                    $init_name = $row['name'];
                    $init_description = $row['description'];
                    $init_price = $row['price'];
                    $init_image = $row['image'];
                ?>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']).'?id='.$init_id;?>">
                    <div class="mb-3">
                        <label for="id">ID</label>
                        <input type="text" class="form-control" id="id" name="id" value="<?php echo $init_id?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo $init_name?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" value="<?php echo $init_description?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="price">Price</label>
                        <input type="text" class="form-control" id="price" name="price" value="<?php echo $init_price?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="image">Image</label>
                        <input type="text" class="form-control" id="image" name="image" value="<?php echo $init_image?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">UPDATE</button>
                </form>
                <a href="a.php">
                    <button class="btn btn-secondary mt-3 w-100">RETURN HOME</button>
                </a>
                <?php
                    if (!isset($_POST['id'])) {
                        die();
                    }
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    $description = $_POST['description'];
                    $price = $_POST['price'];
                    $image = $_POST['image'];

                    $query = 'UPDATE `products` SET `id`='.$id.',`name`="'.$name.'",`description`="'.$description.'",`price`="'.$price.'",`image`="'.$image.'" WHERE id='.$init_id;
                    echo $query;
                    $result = $db->query($query);
                    header('location: a.php');
                ?>
            </div>
        </div>
    </div>
</body>
</html>