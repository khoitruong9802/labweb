<?php
require 'db_connect.php';

$id = $_GET['id'];
$query = 'DELETE FROM `products` WHERE ID = '.$id;
$result = $db->query($query);

header('location: a.php');
?>