import requests

url = 'http://localhost/Lab3/phan2/phan2_bai3/d.php'
myobj = {
    'id': '23',
}
for i in range(8, 100):
    myobj['id'] = i
    requests.get(url, myobj)    
