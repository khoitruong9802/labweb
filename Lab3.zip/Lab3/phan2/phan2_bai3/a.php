<?php
require 'db_connect.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Read Products</h1>
        <a href="b.php" class="d-inline-block">
            <button class="btn btn-primary p-2 my-3">Create New Product</button>
        </a>
        <a href="../phan2_bai2/list.php" class="d-inline-block">
            <button class="btn btn-secondary">HOME</button>
        </a>
        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <?php
            $query = 'SELECT * FROM products';
            $result = $db->query($query);
            while ($row = $result->fetch_assoc()) {
                $id = $row['id'];
                $name = $row['name'];
                $description = $row['description'];
                $price = $row['price'];
                $image = $row['image'];

                echo '
                <tr>
                    <td>'.$id.'</td>
                    <td>'.$name.'</td>
                    <td>'.$description.'</td>
                    <td>'.$price.'</td>
                    <td style="min-width: 240px;">
                        <a href="a.php" class="d-inline-block">
                            <button class="btn btn-info mx-1">Read</button>
                        </a>
                        <a href="c.php?id='.$id.'" class="d-inline-block">
                            <button class="btn btn-primary mx-1">Edit</button>
                        </a>
                        <a href="d.php?id='.$id.'" class="d-inline-block">
                            <button class="btn btn-danger mx-1">Delete</button>
                        </a>
                    </td>
                </tr>
                ';
            }
            ?>
        </table>
    </div>
</body>
</html>