<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-6 bg-light">
                <h1 class="text-center">Create Product</h1>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
                    <div class="mb-3">
                        <label for="id">ID</label>
                        <input type="text" class="form-control" id="id" name="id" required>
                    </div>
                    <div class="mb-3">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" required>
                    </div>
                    <div class="mb-3">
                        <label for="price">Price</label>
                        <input type="text" class="form-control" id="price" name="price" required>
                    </div>
                    <div class="mb-3">
                        <label for="image">Image</label>
                        <input type="text" class="form-control" id="image" name="image" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">CREATE</button>
                </form>
                <a href="a.php">
                    <button class="btn btn-secondary mt-3 w-100">RETURN HOME</button>
                </a>
                <?php
                    require 'db_connect.php';

                    if (!isset($_POST['id'])) {
                        die();
                    }
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    $description = $_POST['description'];
                    $price = $_POST['price'];
                    $image = $_POST['image'];

                    $query = "INSERT INTO `products`
                            VALUES(".$id.",'".$name."','".$description."','".$price."','".$image."')";
                    $result = $db->query($query);
                    header('location: a.php');
                ?>
            </div>
        </div>
    </div>
</body>
</html>