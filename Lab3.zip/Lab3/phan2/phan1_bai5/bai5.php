<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center bg-light">
            <div class="col-12 col-md-6">
                <form action="<?php echo $_SERVER["PHP_SELF"]?>" method="POST">
                    <h1 class="fs-4 text-center">Caculator</h1>
                    <div class="input-group">
                        <input type="number" name="operand1" class="form-control form-control-lg text-center" placeholder="Enter operand">
                    </div>
                    <div class="input-group">
                        <select name="operator" id="operator" class="form-select form-control-lg text-center">
                            <option value="add">+</option>
                            <option value="sub">-</option>
                            <option value="multi">*</option>
                            <option value="div">/</option>
                            <option value="expo">^</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <input type="number" name="operand2" class="form-control form-control-lg text-center" placeholder="Enter operand">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">=</button>
                    <div class="input-group">
                        <input type="text" class="form-control form-control-lg text-center" value="<?php
                    if (!isset($_POST["operand1"]) || !isset($_POST["operand2"]) || !isset($_POST["operator"])) {
                        echo "";                  
                    } else {
                        $operand1 = $_POST["operand1"];
                        $operand2 = $_POST["operand2"];
                        $operator = $_POST["operator"];
                        switch ($operator) {
                            case 'add':
                                echo (int)$operand1 + (int)$operand2;
                                break;
                            case 'sub':
                                echo (int)$operand1 - (int)$operand2;
                                break;
                            case 'multi':
                                echo (int)$operand1 * (int)$operand2;
                                break;
                            case 'div':
                                echo (int)$operand1 / (int)$operand2;
                                break;
                            case 'expo':
                                echo (int)$operand1 ** (int)$operand2;
                                break;
                            default:
                                break;
                        }
                    }
                ?>" readonly>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>