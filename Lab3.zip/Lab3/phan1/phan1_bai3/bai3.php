<?php
for ($i = 0; $i < 101; $i++) { 
    if ($i % 2 == 1) {
        echo $i." ";
    }
}
echo "<br>";
$i = 0;
while ($i < 101) {
    if ($i % 2 == 1) {
        echo $i." ";
    }
    $i++;
}
?>